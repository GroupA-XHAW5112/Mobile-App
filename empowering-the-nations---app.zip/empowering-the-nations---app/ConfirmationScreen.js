import { View, Text, StyleSheet,Alert, ScrollView, TouchableOpacity } from 'react-native';

const ConfirmationScreen = ({ route, navigation }) => {
  
  const { name, phone, email, selectedCourses, totalFee } = route.params;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Confirmation</Text>

      <View style={styles.infoContainer}>
        <Text style={styles.label}>Name:</Text>
        <Text style={styles.value}>{name}</Text>
      </View>

      <View style={styles.infoContainer}>
        <Text style={styles.label}>Phone:</Text>
        <Text style={styles.value}>{phone}</Text>
      </View>

      <View style={styles.infoContainer}>
        <Text style={styles.label}>Email:</Text>
        <Text style={styles.value}>{email}</Text>
      </View>

      <Text style={styles.sectionTitle}>Selected Courses:</Text>
      {selectedCourses.map((course, index) => (
        <View key={index} style={styles.courseContainer}>
          <Text style={styles.courseText}>{course.name} - R{course.fee}</Text>
        </View>
      ))}

      <View style={styles.infoContainer}>
        <Text style={styles.totalLabel}>Total Fee:</Text>
        <Text style={styles.totalValue}>R{totalFee}</Text>
      </View>

      <TouchableOpacity
        style={styles.button}
        onPress={() => Alert.alert('Confirmed!', 'Your registration has been confirmed!')}
      >
        <Text style={styles.buttonText}>Confirm</Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#8B4513',
  },
  infoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#8B4513',
  },
  value: {
    fontSize: 18,
    color: '#000',
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#8B4513',
    marginVertical: 15,
  },
  courseContainer: {
    backgroundColor: '#F5F5F5',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  courseText: {
    fontSize: 16,
    color: '#8B4513',
  },
  totalLabel: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#8B4513',
    marginTop: 20,
  },
  totalValue: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#000',
  },
  button: {
    backgroundColor: '#000',
    padding: 15,
    borderRadius: 30,
    marginTop: 30,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 16,
    color: '#FFF',
    fontWeight: 'bold',
  },
});

export default ConfirmationScreen;
