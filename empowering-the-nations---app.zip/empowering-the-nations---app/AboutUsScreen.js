import { View, Text, ImageBackground, StyleSheet, ScrollView } from 'react-native';

const AboutUsScreen = () => {
  return (
    <ImageBackground source={require('./assets/Logo.jpg')} style={styles.backgroundImage}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.headerText}>About Empowering the Nation</Text>
        <Text style={styles.descriptionText}>
          Empowering the Nation was founded in 2018 with the mission to upskill domestic workers and gardeners,
          providing them with valuable skills that make them more marketable and able to earn better wages.
          We offer a range of courses from six-month programs to shorter six-week training sessions, each designed
          to provide practical, hands-on learning. With a focus on personal and professional development, we
          are committed to helping individuals improve their lives and their communities.
        </Text>
        <Text style={styles.missionText}>
          Our mission is to empower the workforce of South Africa by providing affordable, high-quality education and training.
        </Text>
        <Text style={styles.descriptionText}>
          We operate in various locations across Johannesburg, offering flexible training schedules and personalized support for every participant.
          Our courses cover essential topics like First Aid, Child Minding, Cooking, Sewing, Landscaping, and more.
        </Text>
        <Text style={styles.footerText}>
          Join us in building a stronger, more empowered nation.
        </Text>
      </ScrollView>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover', // Ensure the logo covers the background
    justifyContent: 'center',
  },
  container: {
    flexGrow: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.8)', // Semi-transparent white overlay
    paddingHorizontal: 20,
    paddingVertical: 40,
    alignItems: 'center',
  },
  headerText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#8B4513', // Dark brown color for the header
    marginBottom: 20,
    textAlign: 'center',
  },
  descriptionText: {
    fontSize: 16,
    textAlign: 'justify',
    color: '#8B4513',
    marginBottom: 20,
    lineHeight: 24,
  },
  missionText: {
    fontSize: 18,
    fontStyle: 'italic',
    color: '#8B4513',
    marginBottom: 20,
    textAlign: 'center',
  },
  footerText: {
    fontSize: 16,
    textAlign: 'center',
    color: '#8B4513',
    marginTop: 30,
  },
});

export default AboutUsScreen;
