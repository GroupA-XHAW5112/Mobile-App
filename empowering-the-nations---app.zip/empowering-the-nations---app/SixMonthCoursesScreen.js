import { View, Text, Button, TouchableOpacity, ImageBackground, StyleSheet } from 'react-native';

const SixMonthCoursesScreen = ({ navigation }) => {
  return (
    <ImageBackground source={require('./assets/Logo.jpg')} style={styles.backgroundImage}>
      <View style={styles.container}>
        <Text style={styles.headerText}>Six-Month Courses</Text>
        <Text style={styles.descriptionText}>
          Choose from our extensive six-month courses to upskill yourself or your employees.
          These programs provide in-depth knowledge and practical experience to empower participants.
        </Text>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('CourseDetails', { course: 'First Aid' })}>
          <Text style={styles.buttonText}>First Aid</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('CourseDetails', { course: 'Sewing' })}>
          <Text style={styles.buttonText}>Sewing</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('CourseDetails', { course: 'Landscaping' })}>
          <Text style={styles.buttonText}>Landscaping</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('CourseDetails', { course: 'Life Skills' })}>
          <Text style={styles.buttonText}>Life Skills</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 40,
  },
  headerText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#8B4513',
    marginBottom: 10,
    textAlign: 'center',
  },
  descriptionText: {
    fontSize: 16,
    textAlign: 'center',
    color: '#8B4513',
    marginBottom: 30,
  },
  button: {
    backgroundColor: '#F9E79F',
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 30,
    marginVertical: 10,
    width: '100%',
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 18,
    color: '#8B4513',
    fontWeight: 'bold',
  },
});

export default SixMonthCoursesScreen;
