import { View, Text, Image, StyleSheet, ScrollView } from 'react-native';

const ShortCoursesDetailsScreen = ({ route }) => {
  const { course } = route.params;

  // Course details including description and image for each short course
  const courseDetails = {
    'Child Minding': {
      description: 'This course equips learners with the skills to care for children safely and effectively, focusing on child development and safety.',
      image: require('./assets/ChildMinding.jpeg'), // Image for Child Minding
    },
    'Cooking': {
      description: 'Learn essential cooking skills, from meal planning to food preparation, helping participants to cook healthy and tasty meals.',
      image: require('./assets/Cooking.jpeg'), // Image for Cooking
    },
    'Garden Maintenance': {
      description: 'This course provides practical skills for maintaining and designing gardens, covering tools and techniques.',
      image: require('./assets/Garden-maintenance.jpeg'), // Image for Garden Maintenance
    },
  };

  // Check if the course exists in the courseDetails object
  const courseInfo = courseDetails[course];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Conditional rendering in case course details are not found */}
      {courseInfo ? (
        <>
          <Text style={styles.headerText}>{course} Course</Text>
          <Image source={courseInfo.image} style={styles.courseImage} />
          <Text style={styles.descriptionText}>{courseInfo.description}</Text>
        </>
      ) : (
        <View>
          <Text style={styles.errorText}>Course details not found.</Text>
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#FFF8E1', 
  },
  headerText: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#8B4513',
    marginBottom: 20,
    textAlign: 'center',
  },
  courseImage: {
    width: '100%',
    height: 250,
    resizeMode: 'contain',
    borderRadius: 15,
    marginBottom: 20,
  },
  descriptionText: {
    fontSize: 18,
    textAlign: 'center',
    color: '#8B4513',
    paddingHorizontal: 10,
    lineHeight: 24,
  },
  errorText: {
    fontSize: 20,
    color: 'red',
    textAlign: 'center',
  },
});

export default ShortCoursesDetailsScreen;
