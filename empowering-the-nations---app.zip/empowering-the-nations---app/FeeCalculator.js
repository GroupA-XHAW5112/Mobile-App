import { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  StyleSheet,
  ScrollView,
  Alert,
} from 'react-native';

const FeeCalculator = ({ navigation }) => {
  const [selectedCourses, setSelectedCourses] = useState([]);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [total, setTotal] = useState(0); 

  const courses = [
    { name: 'First Aid', fee: 1500 },
    { name: 'Sewing', fee: 1500 },
    { name: 'Landscaping', fee: 1500 },
    { name: 'Life Skills', fee: 1500 },
    { name: 'Child Minding', fee: 750 },
    { name: 'Cooking', fee: 750 },
    { name: 'Garden Maintenance', fee: 750 },
  ];

  const calculateTotal = (selected) => {
    let totalValue = selected.reduce((sum, course) => sum + course.fee, 0);
    let discount = 0;

    if (selected.length === 1) discount = 0;
    else if (selected.length === 2) discount = totalValue * 0.05;
    else if (selected.length === 3) discount = totalValue * 0.10;
    else if (selected.length > 3) discount = totalValue * 0.15;

  totalValue -= discount;
    totalValue += totalValue * 0.15; 

    setTotal(totalValue.toFixed(2)); 
  };

  const handleSelectCourse = (course) => {
    let updatedCourses;
    if (selectedCourses.includes(course)) {
      updatedCourses = selectedCourses.filter(c => c !== course); 
    } else {
      updatedCourses = [...selectedCourses, course]; 
    }

    setSelectedCourses(updatedCourses);
    calculateTotal(updatedCourses); 
  }; 

  const handleSubmit = () => {
    if (!name || !phone || !email || selectedCourses.length === 0) {
      Alert.alert('Error', 'Please fill out all fields and select at least one course.');
      return;
    }

    navigation.navigate('ConfirmationScreen', {
      name,
      phone,
      email,
      selectedCourses,
      totalFee: total, 
    });
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Image source={require('./assets/Logo.jpg')} style={styles.backgroundImage} />

      <View style={styles.overlay}>
        <Text style={styles.title}>Calculate Total Fees</Text>

        <TextInput
          style={styles.input}
          placeholder="Name"
          placeholderTextColor="#8B4513"
          onChangeText={setName}
          value={name}
        />
        <TextInput
          style={styles.input}
          placeholder="Phone"
          keyboardType="numeric"
          placeholderTextColor="#8B4513"
          onChangeText={setPhone}
          value={phone}
        />
        <TextInput
          style={styles.input}
          placeholder="Email"
          keyboardType="email-address"
          placeholderTextColor="#8B4513"
          onChangeText={setEmail}
          value={email}
        />

        <View style={styles.gridContainer}>
          {courses.map((course) => (
            <TouchableOpacity
              key={course.name}
              style={[
                styles.courseButton,
                selectedCourses.includes(course) && styles.selectedCourseButton,
              ]}
              onPress={() => handleSelectCourse(course)}
            >
              <Text
                style={[
                  styles.courseText,
                  selectedCourses.includes(course) && styles.selectedCourseText,]}>{course.name} - R{course.fee}
                  </Text>
            </TouchableOpacity>
          ))}
        </View>

         <Text style={styles.totalText}>
          {`Total: R${total || 0}`}
        </Text>

        <TouchableOpacity style={styles.buttonBlack} onPress={handleSubmit}>
          <Text style={styles.buttonText}>Calculate Total & Proceed</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  backgroundImage: {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    width: '100%',
    height: '100%',
    opacity: 0.2,
  },
  overlay: {
    backgroundColor: 'rgba(245, 222, 179, 0.9)',
    padding: 20,
    borderRadius: 10,
    width: '100%',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#8B4513',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    backgroundColor: '#FFF',
    padding: 10,
    borderRadius: 10,
    marginBottom: 15,
    borderColor: '#8B4513',
    borderWidth: 1,
    width: '100%',
    color: '#000',
  },
  gridContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginVertical: 20,
  },
  courseButton: {
    backgroundColor: '#8B4513',
    padding: 10,
    borderRadius: 10,
    marginBottom: 10,
    width: '48%',
    alignItems: 'center',
  },
  selectedCourseButton: {
    backgroundColor: '#fff',  
    borderColor: '#8B4513',
    borderWidth: 1,
  },
  courseText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  selectedCourseText: {
    color: '#8B4513', 
  },
  buttonBlack: {
    backgroundColor: '#000',
    paddingVertical: 15,
    borderRadius: 30,
    marginVertical: 20,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 16,
    color: '#FFF',
    fontWeight: 'bold',
  },
});

export default FeeCalculator;
