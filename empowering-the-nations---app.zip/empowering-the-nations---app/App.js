import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import 'react-native-gesture-handler';
import HomeScreen from './HomeScreen';
import AboutUsScreen from './AboutUsScreen';
import SixMonthCoursesScreen from './SixMonthCoursesScreen';
import SixWeekCoursesScreen from './SixWeekCoursesScreen';
import CourseDetails from './CourseDetailsScreen';
import ShortCoursesDetailsScreen from './ShortCoursesDetailsScreen'
import FeeCalculator from './FeeCalculator';
import ConfirmationScreen from './ConfirmationScreen';
import ContactDetails from './ContactScreen';

const Stack = createStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} options={{title: 'Empowering the nations'}} />
        <Stack.Screen name="AboutUs" component={AboutUsScreen} />
        <Stack.Screen name="SixMonthCourses" component={SixMonthCoursesScreen} options={{ title: 'Six-Month Courses' }} />
        <Stack.Screen name="SixWeekCourses" component={SixWeekCoursesScreen} options={{ title: 'Six-Week Courses' }} />
        <Stack.Screen name="CourseDetails" component={CourseDetails} options={{ title: 'Course Details' }} />
        
        <Stack.Screen name="FeeCalculator" component={FeeCalculator} options={{ title: 'Fees Calculator' }} />
        <Stack.Screen name="ConfirmationScreen" component={ConfirmationScreen} />
        <Stack.Screen name="ShortCoursesDetails" component={ShortCoursesDetailsScreen} />
        <Stack.Screen name="ContactDetails" component={ContactDetails} options={{ title: 'Contact Us' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};
    <NavigationContainer>
      <Stack.Navigator initialRouteName="FeeCalculator">
        <Stack.Screen name="FeeCalculator" component={FeeCalculator} />
        <Stack.Screen name="ConfirmationScreen" component={ConfirmationScreen} />
      </Stack.Navigator>
    </NavigationContainer>

export default App;
