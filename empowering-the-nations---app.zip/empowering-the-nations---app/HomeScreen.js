import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

const HomeScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      
      <Image source={require('./assets/Logo.jpg')} style={styles.Image} />
      
      <Text style={styles.Title}>Welcome to Empowering the Nation!</Text>
      <Text style={styles.Description}>Upskilling Domestic Workers and Gardeners</Text>

      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('AboutUs')}>
  <Text style={styles.buttonText}>About Us</Text>
</TouchableOpacity>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('SixMonthCourses')}>
        <Text style={styles.buttonText}>View Six-Month Courses</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('SixWeekCourses')}>
        <Text style={styles.buttonText}>View Six-Week Courses</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('FeeCalculator')}>
        <Text style={styles.buttonText}>Calculate Fees</Text>
      </TouchableOpacity>
      
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('ContactDetails')}>
        <Text style={styles.buttonText}>Contact Us</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#F5DEB3',
    justifyContent: 'center', 
    alignItems: 'center',
    paddingHorizontal: 20,
  }, 
  Title: { 
    fontSize: 26, 
    fontWeight: 'bold', 
    color: '#8B4513',
    marginBottom: 10,
    textAlign: 'center',
  }, 
  Description: { 
    fontSize: 16, 
    textAlign: 'center', 
    marginBottom: 30, 
    color: '#8B4513',
    paddingHorizontal: 10,
  },
  Image: {
    width: 250, 
    height: 250, 
    marginBottom: 20, 
    borderRadius: 125, 
  },
  button: {
    width: '100%', 
    backgroundColor: '#000000',
    paddingVertical: 15,
    borderRadius: 30,
    marginVertical: 10,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 18,
    color: '#FFFFFF',
    fontWeight: 'bold',
  },
});

export default HomeScreen;
