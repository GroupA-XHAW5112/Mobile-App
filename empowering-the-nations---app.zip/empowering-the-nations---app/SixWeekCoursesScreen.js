import { View, Text, TouchableOpacity, ImageBackground, StyleSheet } from 'react-native';

export default function SixWeekCoursesScreen({ navigation }) {
  return (
    <ImageBackground source={require('./assets/Logo.jpg')} style={styles.backgroundImage}>
      <View style={styles.container}>
        <Text style={styles.headerText}>Six-Week Courses</Text>
        <Text style={styles.descriptionText}>
          Our six-week short courses provide essential skills for domestic workers and gardeners. 
          These programs are designed to offer focused, hands-on training to empower participants.
        </Text>

        {/* Course Buttons */}
        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('ShortCoursesDetails', { course: 'Child Minding' })}>
          <Text style={styles.buttonText}>Child Minding</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('ShortCoursesDetails', { course: 'Cooking' })}>
          <Text style={styles.buttonText}>Cooking</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('ShortCoursesDetails', { course: 'Garden Maintenance' })}>
          <Text style={styles.buttonText}>Garden Maintenance</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover', 
    justifyContent: 'center',
  },
  container: {
    flex: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 40,
  },
  headerText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#8B4513', 
    marginBottom: 10,
    textAlign: 'center',
  },
  descriptionText: {
    fontSize: 16,
    textAlign: 'center',
    color: '#8B4513',
    marginBottom: 30,
  },
  button: {
    backgroundColor: '#D2B48C', 
    paddingVertical: 15,
    paddingHorizontal: 30,
    borderRadius: 30, 
    marginVertical: 10,
    width: '100%',
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 18,
    color: '#FFFFFF', 
    fontWeight: 'bold',
  },
});
