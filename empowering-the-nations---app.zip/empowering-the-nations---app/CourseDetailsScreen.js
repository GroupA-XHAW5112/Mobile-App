import { View, Text, Image, StyleSheet, ScrollView } from 'react-native';

const CourseDetailsScreen = ({ route }) => {
  const { course } = route.params;

  const courseDetails = {
    'First Aid': {
      description: 'This course teaches you the essential first aid skills required in emergency situations.',
      image: require('./assets/FirstAid.jpeg'),
    },
    'Sewing': {
      description: 'Learn the art of sewing, from basic techniques to advanced skills.',
      image: require('./assets/Sewing.webp'), 
    },
    'Landscaping': {
      description: 'Gain practical and theoretical knowledge in landscaping design and maintenance.',
      image: require('./assets/Landscaping.jpeg'), 
    },
    'Life Skills': {
      description: 'This course offers a comprehensive guide to essential life skills such as communication, decision-making, and personal management.',
      image: require('./assets/LifeSkills.jpeg'), 
    },
  };

  const { description, image } = courseDetails[course];

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.headerText}>{course} Course</Text>
      <Image source={image} style={styles.courseImage} />
      <Text style={styles.descriptionText}>{description}</Text>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#FFF8E1', 
  },
  headerText: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#8B4513',
    marginBottom: 20,
    textAlign: 'center',
  },
  courseImage: {
    width: '100%',
    height: 250,
    resizeMode: 'contain',
    borderRadius: 15,
    marginBottom: 20,
  },
  descriptionText: {
    fontSize: 18,
    textAlign: 'center',
    color: '#8B4513',
    paddingHorizontal: 10,
    lineHeight: 24,
  },
});

export default CourseDetailsScreen;
